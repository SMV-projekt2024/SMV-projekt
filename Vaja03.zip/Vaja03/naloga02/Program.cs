﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace naloga02
{
    internal class Program
    {
        public static class LikiFormule
        {
            // Javni konstanten podatek PI
            public const double PI = 3.14;

            // Metoda za izračun površine kvadrata
            public static double PloscinaKvadrata(double stranica)
            {
                return stranica * stranica;
            }

            // Metoda za izračun obsega kvadrata
            public static double ObsegKvadrata(double stranica)
            {
                return 4 * stranica;
            }

            // Metoda za izračun površine pravokotnika
            public static double PloscinaPravokotnika(double dolzina, double sirina)
            {
                return dolzina * sirina;
            }

            // Metoda za izračun obsega pravokotnika
            public static double ObsegPravokotnika(double dolzina, double sirina)
            {
                return 2 * (dolzina + sirina);
            }

            // Metoda za izračun površine kroga
            public static double PloscinaKroga(double polmer)
            {
                return PI * polmer * polmer;
            }

            // Metoda za izračun obsega kroga
            public static double ObsegKroga(double polmer)
            {
                return 2 * PI * polmer;
            }

            // Metoda za izračun površine trikotnika z uporabo osnovne formule (baza in višina)
            public static double PloscinaTrikotnika(double baza, double visina)
            {
                return 0.5 * baza * visina;
            }

            // Preobremenjena metoda za izračun površine trikotnika z uporabo Heronovega obrazca
            public static double PloscinaTrikotnika(double a, double b, double c)
            {
                // Heronov obrazec: s = (a + b + c) / 2, A = sqrt(s * (s - a) * (s - b) * (s - c))
                double s = (a + b + c) / 2;
                return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
            }

            // Metoda za izračun obsega trikotnika
            public static double ObsegTrikotnika(double a, double b, double c)
            {
                return a + b + c;
            }
            class Program
            {
                static void Main(string[] args)
                {
                    // Izračuni in izpisi za različne like

                    // Kvadrat
                    double stranicaKvadrata = 5;
                    Console.WriteLine("Površina kvadrata: " + LikiFormule.PloscinaKvadrata(stranicaKvadrata));
                    Console.WriteLine("Obseg kvadrata: " + LikiFormule.ObsegKvadrata(stranicaKvadrata));

                    // Pravokotnik
                    double dolzinaPravokotnika = 7;
                    double sirinaPravokotnika = 4;
                    Console.WriteLine("Površina pravokotnika: " + LikiFormule.PloscinaPravokotnika(dolzinaPravokotnika, sirinaPravokotnika));
                    Console.WriteLine("Obseg pravokotnika: " + LikiFormule.ObsegPravokotnika(dolzinaPravokotnika, sirinaPravokotnika));

                    // Krog
                    double polmerKroga = 3;
                    Console.WriteLine("Površina kroga: " + LikiFormule.PloscinaKroga(polmerKroga));
                    Console.WriteLine("Obseg kroga: " + LikiFormule.ObsegKroga(polmerKroga));

                    // Trikotnik (baza in višina)
                    double bazaTrikotnika = 6;
                    double visinaTrikotnika = 4;
                    Console.WriteLine("Površina trikotnika (z višino): " + LikiFormule.PloscinaTrikotnika(bazaTrikotnika, visinaTrikotnika));

                    // Trikotnik (Heronov obrazec)
                    double a = 3, b = 4, c = 5;
                    Console.WriteLine("Površina trikotnika (Heronov obrazec): " + LikiFormule.PloscinaTrikotnika(a, b, c));
                    Console.WriteLine("Obseg trikotnika: " + LikiFormule.ObsegTrikotnika(a, b, c));

                    // Preprečimo takojšnje zaprtje konzole
                    Console.WriteLine("Pritisnite katerokoli tipko za zaprtje...");
                    Console.ReadLine();
                }
            }
        }
    }
}
