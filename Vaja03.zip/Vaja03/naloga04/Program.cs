﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace naloga04
{
    internal class Program
    { }

namespace CDteka
    {
        public class CD
        {
            // Privatni podatki
            private string naslov;
            private string band;
            private string zvrst;
            private int steviloSkladb;
            private Skladba[] skladbe;

            // Javne lastnosti
            public string Naslov { get { return naslov; } }
            public string Band { get { return band; } }
            public string Zvrst { get { return zvrst; } }
            public int SteviloSkladb { get { return steviloSkladb; } }
            public Skladba[] Skladbe { get { return skladbe; } }

            // Konstruktor
            public CD(string naslov, string band, string zvrst, int steviloSkladb)
            {
                this.naslov = naslov;
                this.band = band;
                this.zvrst = zvrst;

                // Preverjanje števila skladb
                if (steviloSkladb < 1)
                    this.steviloSkladb = 1;
                else if (steviloSkladb > 50)
                    this.steviloSkladb = 50;
                else
                    this.steviloSkladb = steviloSkladb;

                // Inicializacija polja skladb
                skladbe = new Skladba[this.steviloSkladb];
            }

            // Dodaj skladbo v CD
            public void DodajSkladbo(int index, Skladba skladba)
            {
                if (index >= 0 && index < steviloSkladb)
                    skladbe[index] = skladba;
            }

            // Izpis vseh skladb
            public void IzpisSkladb()
            {
                Console.WriteLine($"CD: {naslov} - {band} ({zvrst})");
                for (int i = 0; i < steviloSkladb; i++)
                {
                    if (skladbe[i] != null)
                    {
                        Console.WriteLine($"Skladba {i + 1}: {skladbe[i].Naslov}, Avtor glasbe: {skladbe[i].AvtorGlasbe}, Avtor besedila: {skladbe[i].AvtorBesedila}, Dolžina: {skladbe[i].DolzinaVSekundah} sekund");
                    }
                }
            }

            // Metoda za določanje najdaljše skladbe
            public Skladba NajdaljsaSkladba()
            {
                Skladba najdaljsa = skladbe[0];
                for (int i = 1; i < steviloSkladb; i++)
                {
                    if (skladbe[i] != null && skladbe[i].DolzinaVSekundah > najdaljsa.DolzinaVSekundah)
                    {
                        najdaljsa = skladbe[i];
                    }
                }
                return najdaljsa;
            }

            // Metoda za določanje najkrajše skladbe
            public Skladba NajkrajšaSkladba()
            {
                Skladba najkrajša = skladbe[0];
                for (int i = 1; i < steviloSkladb; i++)
                {
                    if (skladbe[i] != null && skladbe[i].DolzinaVSekundah < najkrajša.DolzinaVSekundah)
                    {
                        najkrajša = skladbe[i];
                    }
                }
                return najkrajša;
            }
        }
    }
    namespace CDteka
    {
        public class Skladba
        {
            // Privatni podatki
            private string naslov;
            private string avtorGlasbe;
            private string avtorBesedila;
            private int dolzinaVSekundah;

            // Javne lastnosti
            public string Naslov { get { return naslov; } }
            public string AvtorGlasbe { get { return avtorGlasbe; } }
            public string AvtorBesedila { get { return avtorBesedila; } }
            public int DolzinaVSekundah
            {
                get { return dolzinaVSekundah; }
                set
                {
                    if (value < 1)
                        dolzinaVSekundah = 1;
                    else if (value > 5000)
                        dolzinaVSekundah = 5000;
                    else
                        dolzinaVSekundah = value;
                }
            }

            // Konstruktor
            public Skladba(string naslov, string avtorGlasbe, string avtorBesedila, int dolzinaVSekundah)
            {
                this.naslov = naslov;
                this.avtorGlasbe = avtorGlasbe;
                this.avtorBesedila = avtorBesedila;
                DolzinaVSekundah = dolzinaVSekundah; // Uporabi setter za preverjanje dolžine
            }
        }
    }
}

