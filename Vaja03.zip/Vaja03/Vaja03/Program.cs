﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vaja03
{
    internal class Program
    {
        public class Datum
        {
            public int Dan { get; set; }
            public int Mesec { get; set; }
            public int Leto { get; set; }

            public Datum(int dan, int mesec, int leto)
            {
                Dan = dan;
                Mesec = mesec;
                Leto = leto;
            }

            public override string ToString()
            {
                return $"{Dan}.{Mesec}.{Leto}";
            }

        static void Main(string[] args)
        {
            // Uporabimo Datum iz prve knjižnice (Datum_TriStevila)
            Datum datum = new Datum(15, 10, 2024);

            // Izpišemo datum
            Console.WriteLine("Datum: " + datum);
            Console.ReadLine();
            }
    }
    }
    
    public class Datum
    {
        private DateTime datumValue;

        // Lastnosti morajo ostati enake kot v prvi implementaciji
        public int Dan
        {
            get { return datumValue.Day; }
            set { datumValue = new DateTime(datumValue.Year, datumValue.Month, value); }
        }

        public int Mesec
        {
            get { return datumValue.Month; }
            set { datumValue = new DateTime(datumValue.Year, value, datumValue.Day); }
        }

        public int Leto
        {
            get { return datumValue.Year; }
            set { datumValue = new DateTime(value, datumValue.Month, datumValue.Day); }
        }

        // Konstrukt mora ostati enak kot v prvi implementaciji
        public Datum(int dan, int mesec, int leto)
        {
            datumValue = new DateTime(leto, mesec, dan);
        }

        // ToString metoda mora vrniti isti format kot v prvi implementaciji
        public override string ToString()
        {
            return $"{Dan}.{Mesec}.{Leto}";
        }
    }

}
