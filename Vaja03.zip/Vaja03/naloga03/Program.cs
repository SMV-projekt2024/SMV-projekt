﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace naloga03
{
    internal class Program
    {
        // Razred Krog
        public class Krog
        {
            private double r; // polmer
            public readonly double Ploscina;
            public readonly double Obseg;

            // Privzeti konstruktor
            public Krog()
            {
                r = 1; // smiselna privzeta vrednost
                Ploscina = LikiFormule.PloscinaKroga(r);
                Obseg = LikiFormule.ObsegKroga(r);
            }

            // Pretvorbeni konstruktor
            public Krog(double polmer)
            {
                r = polmer > 0 ? polmer : 0;
                Ploscina = LikiFormule.PloscinaKroga(r);
                Obseg = LikiFormule.ObsegKroga(r);
            }

            // Kopirni konstruktor
            public Krog(Krog drugKrog)
            {
                r = drugKrog.r;
                Ploscina = drugKrog.Ploscina;
                Obseg = drugKrog.Obseg;
            }
        }

        // Razred Trikotnik
        public class Trikotnik
        {
            private double a, b, c;
            public readonly double Ploscina;
            public readonly double Obseg;

            // Privzeti konstruktor
            public Trikotnik()
            {
                a = b = c = 1; // smiselna privzeta vrednost
                Ploscina = LikiFormule.PloscinaTrikotnika(a, b, c);
                Obseg = LikiFormule.ObsegTrikotnika(a, b, c);
            }

            // Pretvorbeni konstruktor
            public Trikotnik(double stranicaA, double stranicaB, double stranicaC)
            {
                a = stranicaA > 0 ? stranicaA : 0;
                b = stranicaB > 0 ? stranicaB : 0;
                c = stranicaC > 0 ? stranicaC : 0;
                Ploscina = LikiFormule.PloscinaTrikotnika(a, b, c);
                Obseg = LikiFormule.ObsegTrikotnika(a, b, c);
            }

            // Kopirni konstruktor
            public Trikotnik(Trikotnik drugTrikotnik)
            {
                a = drugTrikotnik.a;
                b = drugTrikotnik.b;
                c = drugTrikotnik.c;
                Ploscina = drugTrikotnik.Ploscina;
                Obseg = drugTrikotnik.Obseg;
            }
        }

        // Razred Kvadrat
        public class Kvadrat
        {
            private double stranica;

            // Samo bralna lastnost Ploscina
            public double Ploscina
            {
                get { return LikiFormule.PloscinaKvadrata(stranica); }
            }

            // Samo bralna lastnost Obseg
            public double Obseg
            {
                get { return LikiFormule.ObsegKvadrata(stranica); }
            }

            // Privzeti konstruktor
            public Kvadrat()
            {
                stranica = 1; // smiselna privzeta vrednost
            }

            // Pretvorbeni konstruktor
            public Kvadrat(double stranicaKvadrata)
            {
                stranica = stranicaKvadrata > 0 ? stranicaKvadrata : 0;
            }

            // Kopirni konstruktor
            public Kvadrat(Kvadrat drugKvadrat)
            {
                stranica = drugKvadrat.stranica;
            }
        }

        // Razred Pravokotnik
        public class Pravokotnik
        {
            private double dolzina, sirina;

            // Samo bralna lastnost Ploscina
            public double Ploscina
            {
                get { return LikiFormule.PloscinaPravokotnika(dolzina, sirina); }
            }

            // Samo bralna lastnost Obseg
            public double Obseg
            {
                get { return LikiFormule.ObsegPravokotnika(dolzina, sirina); }
            }

            // Privzeti konstruktor
            public Pravokotnik()
            {
                dolzina = 2; // smiselna privzeta vrednost
                sirina = 1;  // smiselna privzeta vrednost
            }

            // Pretvorbeni konstruktor
            public Pravokotnik(double dolzinaPravokotnika, double sirinaPravokotnika)
            {
                dolzina = dolzinaPravokotnika > 0 ? dolzinaPravokotnika : 0;
                sirina = sirinaPravokotnika > 0 ? sirinaPravokotnika : 0;
            }

            // Kopirni konstruktor
            public Pravokotnik(Pravokotnik drugPravokotnik)
            {
                dolzina = drugPravokotnik.dolzina;
                sirina = drugPravokotnik.sirina;
            }
        }
        public static class LikiFormule
        {
            // Konstanta PI
            public const double PI = 3.14;

            // Metoda za izračun ploščine kvadrata
            public static double PloscinaKvadrata(double stranica)
            {
                return stranica * stranica;
            }

            // Metoda za izračun obsega kvadrata
            public static double ObsegKvadrata(double stranica)
            {
                return 4 * stranica;
            }

            // Metoda za izračun ploščine pravokotnika
            public static double PloscinaPravokotnika(double dolzina, double sirina)
            {
                return dolzina * sirina;
            }

            // Metoda za izračun obsega pravokotnika
            public static double ObsegPravokotnika(double dolzina, double sirina)
            {
                return 2 * (dolzina + sirina);
            }

            // Metoda za izračun ploščine kroga
            public static double PloscinaKroga(double polmer)
            {
                return PI * polmer * polmer;
            }

            // Metoda za izračun obsega kroga
            public static double ObsegKroga(double polmer)
            {
                return 2 * PI * polmer;
            }

            // Metoda za izračun ploščine trikotnika (po formuli s heronskim obrazcem)
            public static double PloscinaTrikotnika(double a, double b, double c)
            {
                double s = (a + b + c) / 2; // polovični obseg
                return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
            }

            // Metoda za izračun obsega trikotnika
            public static double ObsegTrikotnika(double a, double b, double c)
            {
                return a + b + c;
            }
        }

        static void Main(string[] args)
        {
            // Ustvarjanje objektov in izpis rezultatov

            // Krog
            Krog krog1 = new Krog();
            Krog krog2 = new Krog(3);
            Console.WriteLine($"Krog 1 - Ploscina: {krog1.Ploscina}, Obseg: {krog1.Obseg}");
            Console.WriteLine($"Krog 2 - Ploscina: {krog2.Ploscina}, Obseg: {krog2.Obseg}");

            // Trikotnik
            Trikotnik trikotnik1 = new Trikotnik();
            Trikotnik trikotnik2 = new Trikotnik(3, 4, 5);
            Console.WriteLine($"Trikotnik 1 - Ploscina: {trikotnik1.Ploscina}, Obseg: {trikotnik1.Obseg}");
            Console.WriteLine($"Trikotnik 2 - Ploscina: {trikotnik2.Ploscina}, Obseg: {trikotnik2.Obseg}");

            // Kvadrat
            Kvadrat kvadrat1 = new Kvadrat();
            Kvadrat kvadrat2 = new Kvadrat(4);
            Console.WriteLine($"Kvadrat 1 - Ploscina: {kvadrat1.Ploscina}, Obseg: {kvadrat1.Obseg}");
            Console.WriteLine($"Kvadrat 2 - Ploscina: {kvadrat2.Ploscina}, Obseg: {kvadrat2.Obseg}");

            // Pravokotnik
            Pravokotnik pravokotnik1 = new Pravokotnik();
            Pravokotnik pravokotnik2 = new Pravokotnik(6, 3);
            Console.WriteLine($"Pravokotnik 1 - Ploscina: {pravokotnik1.Ploscina}, Obseg: {pravokotnik1.Obseg}");
            Console.WriteLine($"Pravokotnik 2 - Ploscina: {pravokotnik2.Ploscina}, Obseg: {pravokotnik2.Obseg}");

            // Preprečimo zaprtje programa
            Console.WriteLine("Pritisnite katerokoli tipko za izhod...");
            Console.ReadKey();
        }
    }
}

